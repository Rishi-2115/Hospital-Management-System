# Hospital-Managment-System-in-C
This is my first Project in C language.

I have successfully completed by First C program

This project is helpful to keep details of Patient,Employee.Inventory in the Hospital.

These operations can be done.
            1.Enter a New Entry
            
             2.Modify Existing
             
            3.Search an Entry
            
            4.Listing of records
            
            5.Delete an Entry
            
            6.Main Menu

Basic Information of the patient,Employee,Inventory is taken from the user       
